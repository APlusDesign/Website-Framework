<div class="_404">
    <h2>404 - page not found</h2>
</div>