
<p>Thanks for registering</p>
<p>We have sent you an email just to verify you as real human</p>
<p><a href="/" title="">_back</a></p>
