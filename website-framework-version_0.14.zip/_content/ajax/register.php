<div id="pre-window-wrap">
    <h3>Register</h3>
    <div class="user-form">
        <form id="registration" method="post" action="/ajax/switch.php?flag=register">
        	<div id="reg-username" class="input-wrap">
            	<label>Username:</label>
            	<input type="text" name="username" />
            </div>
            <div id="reg-password" class="input-wrap">
            	<label>Password:</label>
            	<input type="password" name="password" />
            </div>
            <div id="reg-password2" class="input-wrap">
            	<label>Re-type Password:</label>
            	<input type="password" name="password2" />
            </div>
            <div id="reg-email" class="input-wrap">
            	<label>Email: </label>
            	<input type="text" name="email" value="" />
            </div>
            <div class="register-action">
            	<input type="submit" value="Register" />
            </div>
        </form>
    </div>
</div>

