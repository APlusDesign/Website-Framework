	
<div>
  <h2>Edit page for <?php echo $display_title; ?></h2>
  <p>Date joined: <?php echo $u_date; ?></p>
</div>
<pre>
<?php print_r($aUser); ?>
</pre>
